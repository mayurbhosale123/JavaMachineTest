package com.ecommerce.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CategoryProductApplicationTests {

	@Test
	void contextLoads() {
	}

}
